"""Green Solutions canonical data loader.

Loads the MVP Excel workbook and exposes both raw domain tables and a
diagnostic-ready asset summary. The application should depend on this
module rather than directly on Excel columns.
"""
from pathlib import Path
import pandas as pd

DATA_FILE = Path(__file__).resolve().parent / "data" / "green_solutions_sample_data.xlsx"

@pd.api.extensions.register_dataframe_accessor("gs")
class _GSAccessor:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

def load_workbook(path=DATA_FILE):
    return {
        "sites": pd.read_excel(path, sheet_name="Sites"),
        "assets": pd.read_excel(path, sheet_name="Assets"),
        "telemetry": pd.read_excel(path, sheet_name="Telemetry", parse_dates=["timestamp"]),
        "weather": pd.read_excel(path, sheet_name="Weather", parse_dates=["timestamp"]),
        "performance": pd.read_excel(path, sheet_name="Performance"),
        "alarms": pd.read_excel(path, sheet_name="Alarms", parse_dates=["timestamp"]),
        "work_orders": pd.read_excel(path, sheet_name="Work_Orders"),
    }

def build_diagnostic_summary(tables):
    """Create one row per asset with evidence useful to the diagnostic agent."""
    assets = tables["assets"].copy()
    telemetry = tables["telemetry"].copy()

    agg = (
        telemetry.groupby("asset_id", as_index=False)
        .agg(
            avg_output_kw=("power_kW", "mean"),
            avg_expected_kw=("expected_power_kW", "mean"),
            max_temp_c=("temperature_C", "max"),
            avg_efficiency_pct=("efficiency_pct", "mean"),
            reading_count=("timestamp", "count"),
            abnormal_count=("status", lambda s: int((~s.isin(["OK","CHARGING","DISCHARGING","IDLE","RUNNING"])).sum())),
        )
    )
    agg["performance_pct"] = (
        agg["avg_output_kw"] / agg["avg_expected_kw"].replace(0, pd.NA) * 100
    ).round(2)
    agg["gap_pct"] = (100 - agg["performance_pct"]).round(2)

    out = assets.merge(agg, on="asset_id", how="inner")
    return out

def portfolio_kpis(tables):
    sites = tables["sites"]
    assets = tables["assets"]
    telemetry = tables["telemetry"]
    performance = tables["performance"]
    alarms = tables["alarms"]
    work_orders = tables["work_orders"]

    actual = performance["actual_kWh"].sum()
    expected = performance["expected_kWh"].sum()
    return {
        "sites": len(sites),
        "assets": len(assets),
        "capacity_mw": round(sites["site_capacity_kW"].sum() / 1000, 2),
        "performance_pct": round(actual / expected * 100, 2) if expected else 0,
        "active_alarms": int(alarms["status"].isin(["Open", "Acknowledged"]).sum()),
        "open_work_orders": int((work_orders["status"] != "Resolved").sum()),
        "telemetry_rows": len(telemetry),
        "lost_kwh": round(performance["lost_kWh"].sum(), 1),
        "revenue_loss_usd": round(performance["estimated_revenue_loss_usd"].sum(), 2),
    }
