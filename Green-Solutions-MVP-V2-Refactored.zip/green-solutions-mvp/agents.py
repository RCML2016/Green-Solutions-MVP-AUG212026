"""Agent nodes for Green Solutions MVP.

The diagnostic layer now consumes the canonical Excel dataset while retaining
backward compatibility with the original synthetic CSV format.
"""
import os
import pandas as pd
from state import PipelineState, AssetDiagnosis
from data_loader import load_workbook, build_diagnostic_summary

def get_llm():
    if os.getenv("OLLAMA_MODEL"):
        from langchain_community.chat_models import ChatOllama
        return ChatOllama(model=os.environ["OLLAMA_MODEL"], temperature=0.2)
    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        temperature=0.2,
        google_api_key=os.environ.get("GOOGLE_API_KEY"),
    )

def data_normalizer_node(state: PipelineState) -> dict:
    path = state["raw_data_path"]

    if str(path).lower().endswith((".xlsx", ".xls")):
        tables = load_workbook(path)
        summary_df = build_diagnostic_summary(tables)
        summary_lines = []
        for r in summary_df.itertuples():
            summary_lines.append(
                f"- {r.asset_id}: type={r.asset_type}, make={r.make}, "
                f"capacity={r.nameplate_kW:.1f}kW, avg_output={r.avg_output_kw:.1f}kW, "
                f"expected_output={r.avg_expected_kw:.1f}kW, performance={r.performance_pct:.1f}%, "
                f"gap={r.gap_pct:.1f}%, max_temp={r.max_temp_c:.1f}C, "
                f"efficiency={r.avg_efficiency_pct:.1f}%, abnormal_intervals={r.abnormal_count}"
            )
        return {
            "normalized_df": summary_df,
            "portfolio_summary": "\n".join(summary_lines),
            "next_step": "diagnose",
        }

    # Original CSV compatibility
    df = pd.read_csv(path, parse_dates=["timestamp"])
    summary_lines = []
    for asset_id, group in df.groupby("asset_id"):
        capacity = group["capacity_kw"].iloc[0]
        avg_gen = group["generation_kw"].mean()
        null_pct = group["generation_kw"].isna().mean() * 100
        fault_days = group.loc[group["injected_fault"] != "none", "timestamp"].nunique()
        summary_lines.append(
            f"- {asset_id}: capacity={capacity}kW, avg_output={avg_gen:.1f}kW, "
            f"missing_readings={null_pct:.1f}%, flagged_intervals={fault_days}"
        )
    return {"normalized_df": df, "portfolio_summary": "\n".join(summary_lines), "next_step": "diagnose"}

DIAGNOSTIC_PROMPT = """You are a renewable-energy O&M diagnostics engineer.

Analyze the asset summaries below. Identify abnormal assets and the most
likely operational issue. Use only evidence present in the numbers.
Possible categories include:
- underperformance
- inverter derating/clipping
- overheating
- communication/data-quality issue
- normal

For each asset, respond exactly:
ASSET: <asset_id>
FAULT: <category>
CONFIDENCE: <0.0-1.0>
EVIDENCE: <one sentence grounded in the numbers>
ACTION: <one concrete next step>

Do not invent alarms, weather observations, or financial values not provided.

Portfolio summary:
{summary}
"""

def diagnostic_reasoner_node(state: PipelineState) -> dict:
    llm = get_llm()
    prompt = DIAGNOSTIC_PROMPT.format(summary=state["portfolio_summary"])
    response = llm.invoke(prompt)
    text = response.content if hasattr(response, "content") else str(response)

    diagnoses = []
    for block in [b.strip() for b in text.split("ASSET:") if b.strip()]:
        lines = ("ASSET:" + block).splitlines()
        fields = {}
        for line in lines:
            if ":" in line:
                key, _, val = line.partition(":")
                fields[key.strip().upper()] = val.strip()
        if "ASSET" not in fields:
            continue
        try:
            confidence = max(0.0, min(1.0, float(fields.get("CONFIDENCE", "0.5"))))
        except ValueError:
            confidence = 0.5
        diagnoses.append(AssetDiagnosis(
            asset_id=fields.get("ASSET", "unknown"),
            fault_hypothesis=fields.get("FAULT", "unknown"),
            confidence=confidence,
            evidence=fields.get("EVIDENCE", ""),
            recommended_action=fields.get("ACTION", ""),
        ))

    low_confidence = [d for d in diagnoses if d["confidence"] < 0.6]
    return {
        "diagnoses": diagnoses,
        "needs_human_review": bool(low_confidence),
        "review_reason": f"{len(low_confidence)} diagnosis(es) below 0.6 confidence" if low_confidence else None,
        "next_step": "human_review" if low_confidence else "draft_reports",
    }

REPORT_PROMPT = """You are drafting three concise documents from renewable-energy diagnostic findings.

Diagnoses:
{diagnoses}

Produce exactly:
=== WORK_ORDER ===
Technical field instructions.

=== OWNER_REPORT ===
Plain-English portfolio summary.

=== COMPLIANCE_SUMMARY ===
Formal record of findings and actions.
"""

def report_drafter_node(state: PipelineState) -> dict:
    llm = get_llm()
    diag_text = "\n".join(
        f"- {d['asset_id']}: {d['fault_hypothesis']} "
        f"(confidence {d['confidence']:.2f}) — {d['evidence']} Action: {d['recommended_action']}"
        for d in state["diagnoses"]
    )
    response = llm.invoke(REPORT_PROMPT.format(diagnoses=diag_text))
    text = response.content if hasattr(response, "content") else str(response)

    sections = {"WORK_ORDER": "", "OWNER_REPORT": "", "COMPLIANCE_SUMMARY": ""}
    current = None
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("=== ") and stripped.endswith(" ==="):
            current = stripped.strip("= ").strip()
        elif current in sections:
            sections[current] += line + "\n"
    return {
        "work_order_text": sections["WORK_ORDER"].strip(),
        "owner_report_text": sections["OWNER_REPORT"].strip(),
        "compliance_summary_text": sections["COMPLIANCE_SUMMARY"].strip(),
        "next_step": "done",
    }

def human_review_node(state: PipelineState) -> dict:
    return {"next_step": "draft_reports"}
