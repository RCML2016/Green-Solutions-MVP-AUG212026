# Green Solutions MVP V2

V2 is a focused UX and code-structure refactor of the Green Solutions renewable asset intelligence MVP.

## Product navigation

- **Overview** — portfolio health, KPIs and priority sites
- **Sites** — site-first portfolio view with site intelligence
- **Alerts** — operational alerts and AI findings
- **AI Insights** — evidence, impact, confidence and recommended action
- **Reports** — performance summary, generated reports and pilot feedback

## Architecture

```text
Streamlit UI
  ├── Overview
  ├── Sites
  ├── Alerts
  ├── AI Insights
  └── Reports
        ↓
Core data / metrics / risk / insights
        ↓
Existing canonical Excel data loader
        ↓
Existing LangGraph pipeline
  data_normalizer → diagnostic_reasoner → human_review → report_drafter
```

The existing AI pipeline and canonical workbook remain intact. V2 primarily separates UI concerns from business/data logic and reduces navigation complexity.

## Data validation

The included workbook currently contains 380 sites, 5,473 assets, 60,000 telemetry rows, 9,120 weather rows, 380 performance rows, 800 alarms and 141 work orders. These are read dynamically by the existing `data_loader.py`.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

AI diagnostics require the configured Google Gemini credentials or the existing Ollama configuration supported by `agents.py`.
