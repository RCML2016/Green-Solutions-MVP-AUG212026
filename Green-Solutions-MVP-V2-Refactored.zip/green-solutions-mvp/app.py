from pathlib import Path
import streamlit as st

from data_loader import load_workbook
from graph import build_graph
from core.metrics import portfolio_metrics
from core.data import build_site_view
from ui.theme import apply_theme
from ui.navigation import render_navigation
from ui.pages import overview, sites, alerts, insights, reports

st.set_page_config(page_title="Green Solutions", page_icon="🌱", layout="wide", initial_sidebar_state="expanded")
apply_theme()

DATA_FILE = Path(__file__).resolve().parent / "data" / "green_solutions_sample_data.xlsx"

@st.cache_data(show_spinner=False)
def load_data():
    return load_workbook(DATA_FILE)

@st.cache_resource(show_spinner=False)
def get_pipeline():
    return build_graph()

def run_pipeline(path):
    return get_pipeline().invoke({"raw_data_path": str(path), "dataset_name": "Green Solutions Sample Dataset"})

tables = load_data()
metrics = portfolio_metrics(tables)
site_view = build_site_view(tables)
page = render_navigation()

if page == "Overview":
    overview.render(tables, metrics, site_view)
elif page == "Sites":
    sites.render(tables, site_view, None)
elif page == "Alerts":
    alerts.render(tables, site_view, st.session_state.get("diagnostic_result"))
elif page == "AI Insights":
    insights.render(tables, run_pipeline, DATA_FILE)
elif page == "Reports":
    reports.render(tables, metrics)

st.caption("Green Solutions MVP • Synthetic data • Replace the source with OEM/SCADA integrations during pilot validation.")
