import pandas as pd


def merge_diagnostics_with_assets(tables):
    from data_loader import build_diagnostic_summary
    return build_diagnostic_summary(tables)


def normalize_diagnoses(diagnoses):
    rows = []
    for d in diagnoses or []:
        rows.append({
            "asset_id": d.get("asset_id", ""),
            "issue": d.get("fault_hypothesis", ""),
            "confidence": float(d.get("confidence", 0)),
            "evidence": d.get("evidence", ""),
            "recommended_action": d.get("recommended_action", ""),
        })
    return pd.DataFrame(rows)
