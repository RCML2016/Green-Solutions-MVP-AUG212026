import pandas as pd


def portfolio_metrics(tables):
    sites = tables["sites"]
    assets = tables["assets"]
    performance = tables["performance"]
    alarms = tables["alarms"]
    work_orders = tables["work_orders"]

    expected = performance["expected_kWh"].sum()
    actual = performance["actual_kWh"].sum()
    active = alarms["status"].isin(["Open", "Acknowledged"]).sum()
    open_wo = (work_orders["status"] != "Resolved").sum()

    return {
        "sites": len(sites),
        "assets": len(assets),
        "capacity_mw": sites["site_capacity_kW"].sum() / 1000,
        "availability_pct": performance["availability_pct"].mean(),
        "performance_pct": (actual / expected * 100) if expected else 0,
        "active_alerts": int(active),
        "open_work_orders": int(open_wo),
        "lost_kwh": performance["lost_kWh"].sum(),
        "revenue_loss_usd": performance["estimated_revenue_loss_usd"].sum(),
    }


def health_distribution(site_view):
    return site_view["health"].value_counts().reindex(["Healthy", "Attention", "Critical"], fill_value=0)


def priority_sites(site_view, n=5):
    return site_view.sort_values(["active_alerts", "revenue_loss_usd", "performance_pct"], ascending=[False, False, True]).head(n)
