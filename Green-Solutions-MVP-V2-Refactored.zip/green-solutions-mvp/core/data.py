from pathlib import Path
import pandas as pd
from data_loader import load_workbook, build_diagnostic_summary

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "green_solutions_sample_data.xlsx"


def load_portfolio(path=DATA_FILE):
    return load_workbook(path)


def build_site_view(tables):
    sites = tables["sites"].copy()
    performance = tables["performance"].copy()
    assets = tables["assets"].copy()
    alarms = tables["alarms"].copy()

    perf = performance.groupby("site_id", as_index=False).agg(
        expected_kwh=("expected_kWh", "sum"),
        actual_kwh=("actual_kWh", "sum"),
        availability_pct=("availability_pct", "mean"),
        lost_kwh=("lost_kWh", "sum"),
        revenue_loss_usd=("estimated_revenue_loss_usd", "sum"),
    )
    perf["performance_pct"] = (perf["actual_kwh"] / perf["expected_kwh"].replace(0, pd.NA) * 100).fillna(0).round(1)

    asset_counts = assets.groupby("site_id").size().rename("asset_count").reset_index()
    open_alarms = alarms[alarms["status"].isin(["Open", "Acknowledged"])].groupby("site_id").size().rename("active_alerts").reset_index()

    out = sites.merge(perf, on="site_id", how="left").merge(asset_counts, on="site_id", how="left").merge(open_alarms, on="site_id", how="left")
    for c in ["asset_count", "active_alerts"]:
        out[c] = out[c].fillna(0).astype(int)
    out["health"] = out.apply(lambda r: "Critical" if r.active_alerts >= 3 or r.performance_pct < 90 else ("Attention" if r.active_alerts > 0 or r.performance_pct < 96 else "Healthy"), axis=1)
    return out
