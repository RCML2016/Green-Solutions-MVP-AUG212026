def risk_level(performance_pct, active_alerts=0, confidence=None):
    if performance_pct < 90 or active_alerts >= 3:
        return "Critical"
    if performance_pct < 96 or active_alerts > 0 or (confidence is not None and confidence < 0.6):
        return "Attention"
    return "Healthy"
