# Green Solutions — AI-Powered Renewable Energy O&M MVP

This version connects the Streamlit MVP to the canonical synthetic renewable-energy dataset.

## Data included

`data/green_solutions_sample_data.xlsx`

Sheets:
- Sites
- Assets
- Telemetry
- Weather
- Performance
- Alarms
- Work_Orders

The application uses this flow:

`Site → Asset → Telemetry → Weather/Performance → AI Diagnostics → Work Order`

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud

1. Push the entire `green-solutions-mvp` folder to GitHub.
2. Create/select the Streamlit app from that repository.
3. Main file: `app.py`.
4. Deploy.
5. The sample dataset is bundled under `data/`, so no database is required for this MVP.

## Optional live Gemini mode

Add `GOOGLE_API_KEY` in Streamlit Secrets. Do not commit API keys.

The first MVP validation can also be run without a key only if the app is configured with a local/demo LLM path. For a production pilot, add a deterministic analytics layer before LLM reasoning.

## Important architecture

Do not make Excel the permanent architecture. `data_loader.py` is the boundary. Later replace the workbook with OEM APIs, SCADA, CMMS and weather integrations while keeping the application/business logic stable.
