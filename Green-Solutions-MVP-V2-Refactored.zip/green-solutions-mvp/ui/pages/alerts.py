import streamlit as st


def render(tables, site_view, diagnostic_result=None):
    st.title("Alerts")
    st.caption("Focus operators on the issues that require attention first.")
    alarms = tables["alarms"].copy()
    active = alarms[alarms["status"].isin(["Open", "Acknowledged"])].copy()
    c1,c2,c3 = st.columns(3)
    c1.metric("Critical", int((active["severity"] == "Critical").sum()) if "severity" in active.columns else "—")
    c2.metric("Active", len(active))
    c3.metric("Resolved", int((alarms["status"] == "Resolved").sum()))
    st.dataframe(active.sort_values("timestamp", ascending=False).head(100), use_container_width=True, hide_index=True)

    if diagnostic_result:
        st.subheader("AI findings linked to alerts")
        rows = [d for d in diagnostic_result.get("diagnoses", []) if d.get("fault_hypothesis", "").lower() != "normal"]
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)
        else:
            st.info("No abnormal AI findings in the current run.")

