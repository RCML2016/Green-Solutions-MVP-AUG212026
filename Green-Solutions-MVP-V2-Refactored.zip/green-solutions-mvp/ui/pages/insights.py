import streamlit as st
from ui.components import insight_card


def render(tables, run_pipeline, data_file):
    st.title("AI Insights")
    st.caption("Turn telemetry and performance evidence into an operator-ready explanation and next action.")
    if st.button("Run AI Diagnostics", type="primary"):
        with st.spinner("Analyzing portfolio..."):
            try:
                st.session_state["diagnostic_result"] = run_pipeline(data_file)
                st.success("Analysis complete.")
            except Exception as exc:
                st.error(f"Diagnostic pipeline error: {exc}")

    result = st.session_state.get("diagnostic_result")
    if not result:
        st.info("Run AI Diagnostics to generate prioritized asset insights.")
        return

    diagnoses = result.get("diagnoses", [])
    abnormal = [d for d in diagnoses if d.get("fault_hypothesis", "").lower() != "normal"]
    c1,c2,c3 = st.columns(3)
    c1.metric("Findings", len(abnormal))
    c2.metric("Human review", "Required" if result.get("needs_human_review") else "Not required")
    c3.metric("Total assets analyzed", len(diagnoses))

    for d in abnormal:
        impact = None
        asset_id = d.get("asset_id")
        if "estimated_revenue_loss_usd" in tables["performance"].columns and "asset_id" in tables["assets"].columns:
            asset_sites = tables["assets"].loc[tables["assets"]["asset_id"] == asset_id, "site_id"]
            if not asset_sites.empty:
                site_id = asset_sites.iloc[0]
                loss = tables["performance"].loc[tables["performance"]["site_id"] == site_id, "estimated_revenue_loss_usd"].sum()
                impact = f"${loss:,.2f} estimated site revenue loss"
        insight_card(asset_id, d.get("fault_hypothesis", "Unknown"), d.get("confidence", 0), d.get("evidence", ""), d.get("recommended_action", ""), impact)

    with st.expander("View generated reports"):
        st.write("**Field Work Order**")
        st.write(result.get("work_order_text", ""))
        st.write("**Owner Report**")
        st.write(result.get("owner_report_text", ""))
        st.write("**Compliance Summary**")
        st.write(result.get("compliance_summary_text", ""))
