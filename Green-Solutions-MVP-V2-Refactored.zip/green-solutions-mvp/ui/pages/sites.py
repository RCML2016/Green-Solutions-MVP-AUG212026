import streamlit as st


def render(tables, site_view, summary):
    st.title("Sites")
    st.caption("Portfolio sites first; detailed asset intelligence is one click away.")
    search = st.text_input("Search sites", placeholder="Site ID, name, type...")
    filtered = site_view.copy()
    if search:
        mask = filtered.astype(str).apply(lambda c: c.str.contains(search, case=False, na=False)).any(axis=1)
        filtered = filtered[mask]

    display_cols = [c for c in ["site_id", "site_name", "site_type", "site_capacity_kW", "asset_count", "performance_pct", "availability_pct", "active_alerts", "health"] if c in filtered.columns]
    st.dataframe(filtered[display_cols], use_container_width=True, hide_index=True)

    if filtered.empty:
        return
    selected = st.selectbox("Open site", filtered["site_id"].tolist())
    site = filtered[filtered["site_id"] == selected].iloc[0]
    st.subheader(f"{selected} · Site Intelligence")
    a,b,c,d = st.columns(4)
    a.metric("Capacity", f"{site['site_capacity_kW']:,.0f} kW")
    b.metric("Performance", f"{site['performance_pct']:.1f}%")
    c.metric("Availability", f"{site['availability_pct']:.1f}%")
    d.metric("Active alerts", int(site['active_alerts']))

    assets = tables["assets"][tables["assets"]["site_id"] == selected].copy()
    if not assets.empty:
        st.write("**Assets**")
        st.dataframe(assets, use_container_width=True, hide_index=True)

    telemetry = tables["telemetry"][tables["telemetry"]["site_id"] == selected].copy()
    if not telemetry.empty:
        chart_cols = [c for c in ["power_kW", "expected_power_kW"] if c in telemetry.columns]
        if chart_cols:
            st.write("**Recent telemetry**")
            st.line_chart(telemetry.set_index("timestamp")[chart_cols])
