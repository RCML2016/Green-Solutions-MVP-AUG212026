import streamlit as st
from core.metrics import health_distribution, priority_sites
from ui.components import page_header, kpi_strip


def render(tables, metrics, site_view):
    page_header("Renewable Asset Intelligence", "Monitor your portfolio. Identify risk. Act earlier.")
    kpi_strip([
        ("Sites", f"{metrics['sites']:,}", None),
        ("Capacity", f"{metrics['capacity_mw']:,.1f} MW", None),
        ("Availability", f"{metrics['availability_pct']:.1f}%", None),
        ("Active Alerts", f"{metrics['active_alerts']:,}", None),
        ("Performance Risk", f"${metrics['revenue_loss_usd']:,.0f}", "Estimated revenue impact in the sample performance data"),
    ])
    st.divider()

    left, right = st.columns([1.4, 1])
    with left:
        st.subheader("Portfolio Health")
        dist = health_distribution(site_view)
        st.bar_chart(dist)
    with right:
        st.subheader("At a glance")
        st.metric("Energy lost", f"{metrics['lost_kwh']:,.0f} kWh")
        st.metric("Open work orders", f"{metrics['open_work_orders']:,}")
        st.metric("Assets monitored", f"{metrics['assets']:,}")

    st.subheader("AI Priority Queue")
    priority = priority_sites(site_view)
    if priority.empty:
        st.success("No priority sites detected.")
    else:
        for _, row in priority.iterrows():
            st.markdown(f"**{row['site_id']}** · {row['health']}  —  {row['performance_pct']:.1f}% performance · {int(row['active_alerts'])} active alerts · ${row['revenue_loss_usd']:,.2f} estimated loss")
