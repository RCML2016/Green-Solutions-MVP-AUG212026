import streamlit as st
from feedback_store import save_feedback


def render(tables, metrics):
    st.title("Reports")
    st.caption("Keep reporting simple in the MVP; generated AI reports are available from AI Insights.")
    c1,c2,c3 = st.columns(3)
    c1.metric("Energy lost", f"{metrics['lost_kwh']:,.0f} kWh")
    c2.metric("Revenue impact", f"${metrics['revenue_loss_usd']:,.2f}")
    c3.metric("Open work orders", metrics["open_work_orders"])

    st.subheader("Performance Summary")
    st.dataframe(tables["performance"].sort_values("estimated_revenue_loss_usd", ascending=False).head(100), use_container_width=True, hide_index=True)

    with st.expander("Canonical Data Explorer"):
        choice = st.selectbox("Dataset", list(tables.keys()))
        df = tables[choice]
        st.caption(f"{len(df):,} rows × {len(df.columns)} columns")
        st.dataframe(df.head(500), use_container_width=True, hide_index=True)

    with st.expander("Pilot Feedback"):
        with st.form("feedback_form"):
            trust = st.slider("Trust without double-checking", 1, 5, 3)
            clarity = st.slider("Output clarity", 1, 5, 3)
            time_saved = st.radio("Would this save time?", ["Yes, clearly", "Somewhat", "Not really", "Not sure"], index=None)
            role = st.text_input("Your role")
            comments = st.text_area("What's missing?")
            if st.form_submit_button("Submit feedback"):
                save_feedback({"trust": trust, "clarity": clarity, "time_saved": time_saved, "role": role, "comments": comments})
                st.success("Feedback saved.")
