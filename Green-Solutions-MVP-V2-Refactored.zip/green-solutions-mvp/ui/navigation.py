import streamlit as st

PAGES = ["Overview", "Sites", "Alerts", "AI Insights", "Reports"]


def render_navigation():
    with st.sidebar:
        st.markdown('<div class="brand">🌱 Green Solutions</div>', unsafe_allow_html=True)
        st.caption("Renewable Asset Intelligence")
        st.divider()
        page = st.radio("Navigate", PAGES, label_visibility="collapsed")
        st.divider()
        st.caption("MVP • Synthetic data")
    return page
