import streamlit as st


def apply_theme():
    st.markdown("""
    <style>
    .block-container { max-width: 1380px; padding-top: 1.4rem; padding-bottom: 3rem; }
    [data-testid="stSidebar"] { border-right: 1px solid #e5e7eb; }
    .brand { font-size: 1.15rem; font-weight: 750; letter-spacing: -0.02em; }
    .subtitle { color: #667085; margin-top: -0.35rem; margin-bottom: 1.25rem; }
    .insight-card { border: 1px solid #e4e7ec; border-radius: 12px; padding: 16px 18px; margin-bottom: 12px; background: #fff; }
    .critical { border-left: 4px solid #c0392b; }
    .attention { border-left: 4px solid #d97706; }
    .healthy { border-left: 4px solid #2f855a; }
    .muted { color: #667085; font-size: .9rem; }
    </style>
    """, unsafe_allow_html=True)
