import streamlit as st


def page_header(title, subtitle=None):
    st.title(title)
    if subtitle:
        st.markdown(f'<div class="subtitle">{subtitle}</div>', unsafe_allow_html=True)


def kpi_strip(metrics):
    cols = st.columns(len(metrics))
    for col, (label, value, help_text) in zip(cols, metrics):
        col.metric(label, value, help=help_text)


def status_badge(status):
    cls = status.lower().replace(" ", "-")
    return f'<span class="{cls}">{status}</span>'


def insight_card(asset_id, issue, confidence, evidence, action, impact=None):
    cls = "critical" if confidence < 0.6 else "attention" if confidence < 0.85 else "healthy"
    impact_html = f"<br><b>Impact:</b> {impact}" if impact else ""
    st.markdown(f'''<div class="insight-card {cls}">
        <div><b>{asset_id}</b> · {issue}</div>
        <div class="muted">Confidence: {confidence:.0%}</div>
        <div><b>Evidence:</b> {evidence}</div>
        <div><b>Recommended action:</b> {action}</div>{impact_html}
    </div>''', unsafe_allow_html=True)
